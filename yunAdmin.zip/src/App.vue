<template>
  <div id="app">
    <router-view />
  </div>
</template>
<script>
export default {
  mouted() {}
};
</script>
<style lang="scss">
.body,
.html,
#app {
  width:100%;
  height: 100%;
}
</style>
